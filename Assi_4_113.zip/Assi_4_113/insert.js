var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Gawandeyash7*",
  database: "AWAMAD1"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  var sql = "insert into club (club_id, club_name, club_head) VALUES ?";
  var values = [
      ['1', 'ACSES', 'Suyash_Savji'],
    ['2', 'PACE', 'Tavishi'],
    [3, 'WLUG', 'Yash_Bhange'],
    [4, 'Selmon_bhoi_fan_club', 'Gadz'],
    [5, 'MIfanclub', 'RS']
  ];
  con.query(sql, [values], function (err, result) {
    if (err) throw err;
    console.log("Data inserted in club table successfully");
  });
});