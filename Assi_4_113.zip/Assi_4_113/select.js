var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Gawandeyash7*",
  database: "AWAMAD1"
});

con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT club_name FROM club", function (err, result, fields) {
    if (err) throw err;
    console.log(fields);
  });
});