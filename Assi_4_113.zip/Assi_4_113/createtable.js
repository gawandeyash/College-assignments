var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Gawandeyash7*",
  database: "AWAMAD1"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  var sql = "CREATE TABLE club (club_id VARCHAR(255), club_name VARCHAR(255), club_head VARCHAR(255))";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table named club created successfully");
  });
});